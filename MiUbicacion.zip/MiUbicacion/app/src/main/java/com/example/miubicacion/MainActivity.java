package com.example.miubicacion;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnRed;
    TextView tvDUbicacion;
    TextView tvLongitud;
    TextView tvLatitud;
    String longitud;
    String latitud;
    Button btnGPS;

    private static final int REQUEST_LOCATION = 1;

    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Add permission
        ActivityCompat.requestPermissions(this, new String[]
                {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        btnRed = (Button) findViewById(R.id.btnPosRed);
        tvDUbicacion = (TextView) findViewById(R.id.tvMensajeAutor);
        btnGPS = (Button) findViewById(R.id.btnPosGps);

        btnGPS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               String ruta= "http://localhost:9000/resigstrar";
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                //Check gps is enable or not

                if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    //write funtion to enable GPS
                    onGPS();
                } else {
                    // GPS is already
                    getLocation();
                }

            }
        });
        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                }

                Location ubicacionNetwork = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

                double lat = ubicacionNetwork.getLatitude();
                double lon = ubicacionNetwork.getLongitude();
                latitud = String.valueOf(lat);
                longitud = String.valueOf(lon);

                tvLatitud.setText(latitud);
                tvLongitud.setText(longitud);

                Toast.makeText(getApplicationContext(), "Estado de Red:" + latitud + gpsEnabled + longitud, Toast.LENGTH_LONG).show();
                tvDUbicacion.setText("Datos por Red: Lon:" + longitud+"Lat:"+latitud);

                Toast.makeText(
                        getApplicationContext(),
                        "Ubicación por RED es: -\nLat: " + latitud+ "\nLong: "
                                + longitud, Toast.LENGTH_LONG).show();

                tvDUbicacion.setText("Datos por RED: Lat:"+latitud+" Lon:"+longitud);
            }
        });
    }

    private void getLocation() {
        //Check perimission again
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
        else {

            Location ubicacionGps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location ubicacionNetwork = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location ubicacionPasiva = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

            if (ubicacionGps != null) {
                double lat = ubicacionGps.getLatitude();
                double lon = ubicacionGps.getLongitude();
                latitud = String.valueOf(lat);
                longitud = String.valueOf(lon);

                tvDUbicacion.setText("GPS:"+latitud + " --" + longitud);
                Toast.makeText(getApplicationContext(), "Estado GPS Encendido/Apagado:" + latitud + gpsEnabled + longitud, Toast.LENGTH_LONG).show();
            } else if (ubicacionNetwork != null) {
                double lat = ubicacionNetwork.getLatitude();
                double lon = ubicacionNetwork.getLongitude();
                latitud = String.valueOf(lat);
                longitud = String.valueOf(lon);

                tvDUbicacion.setText(latitud + " --" + longitud);
                Toast.makeText(getApplicationContext(), "Estado de Red:" + latitud + gpsEnabled + longitud, Toast.LENGTH_LONG).show();
            }
            else if (ubicacionPasiva != null) {
                double lat = ubicacionPasiva.getLatitude();
                double lon = ubicacionPasiva.getLongitude();
                latitud = String.valueOf(lat);
                longitud = String.valueOf(lon);

                tvDUbicacion.setText(latitud + " --" + longitud);
                Toast.makeText(getApplicationContext(), "Ubicacion Pasiva:" + gpsEnabled + latitud, Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(getApplicationContext(), "No se puede conseguir ubicacion" + latitud + gpsEnabled + longitud, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void onGPS() {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Habilitar el GPS").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                      startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                }
            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                     dialog.cancel();
                }
            });
            final AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
}